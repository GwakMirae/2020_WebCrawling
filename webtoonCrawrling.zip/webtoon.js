var request = require('request');
var cheerio = require('cheerio');
var fs = require('fs');

const downloadImage = (path, url, titleId, no) => {
    request(
        {
            url : url,
            headers : {referer: `https://comic.naver.com/webtoon/detail.nhn?titleId=${titleId}&no=${no}&weekday=tue` },
            encoding: null // default 값이 utf-8이기 때문에 null로 설정
        }, function(err, response, body) {
            fs.writeFile(path+'\\'+`${titleId}_${no}_${(url.split('_IMAG')[1])}`, body, null, (err)=>{
                console.log('the file has been saved');
            })
        }
    )
}

const getImageUrl = (titleId, no) => {
    request({ url: `https://comic.naver.com/webtoon/detail.nhn?titleId=${titleId}&no=${no}&weekday=tue`},
        function(err, response, body){
            const $ = cheerio.load(body);
            for(let i=$('.wt_viewer img').length-1; i>$('.wt_viewer img').length-4; i--){
                downloadImage('download', $('.wt_viewer img')[i].attribs.src, titleId, no);
            }  
        } 
    )
}
for(let i=0; i<10; i++){
    setTimeout(()=>{
        getImageUrl(703852, i+116);
    }, 1000);
}
