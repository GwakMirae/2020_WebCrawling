let cheerio = require('cheerio');
var express = require('express');
var request = require('request');

function template(content){
    return `<!DOCTYPE html>
    <html lang="en">
    <head>
        <title>Document</title>
    </head>
    <body>
        <h1>News Crawling</h1>
        <br>
        <br>
        <h2>corona news title</h2>
        ${content}
    </body>
    </html>`;
}

function liMake(arr,arr2){
    var list = '<ul>';
    var i=0;
    while(i< arr.length){
        list = list + `<li><a href=${arr2[i]}>${arr[i]}</a></li>`;
        i++;
    }
    list = list +'</ul>';
    return list;
}

const app = express();
app.get('/', (req, res)=>{
        request({url: `https://search.naver.com/search.naver?sm=tab_hty.top&where=news&query=%EC%BD%94%EB%A1%9C%EB%82%98&oquery=%EC%BD%94%EB%A1%9C%EB%82%98&tqi=UIHX4lp0J1sssFUcmMCssssstOZ-098616`}, function(error, response, body){
            const $ = cheerio.load(body);
            var arr = new Array();
            var arr2 = new Array();
            for(let i=0; i<$('.news_tit').length; i++){
                arr.push($('.news_tit')[i].attribs.title);
                arr2.push($('.news_tit')[i].attribs.href);
            }
            var list = liMake(arr,arr2);

            var html = template(list);
            res.send(html);
        });
});

app.listen(8080);

// var app = http.createServer(function(req, res){

//     var _url = req.url;
//     var pathname = url.parse(_url, true).pathname;

//     if(pathname === '/'){
//         req({url: `https://search.naver.com/search.naver?sm=tab_hty.top&where=news&query=%EC%BD%94%EB%A1%9C%EB%82%98&oquery=%EC%BD%94%EB%A1%9C%EB%82%98&tqi=UIHX4lp0J1sssFUcmMCssssstOZ-098616`}, function(error, response, body){
//             const $ = cheerio.load(body);
//             var arr = Array();
//             for(let i=0; i<$('.news_tit').length; i++){
//                 arr.push($('.news_tit')[i].title);
//             }
//             var list = liMake(arr);
//             var html = template(list);
//             res.writeHead(200);
//             res.end(html);
//         });
//     }else {
//         res.writeHead(404);
//         res.end("hello error");
//     }
// });

// app.listen(3000);