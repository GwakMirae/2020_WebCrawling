var request = require('request');
var cheerio = require('cheerio');
var fs = require('fs');

const getRottoUrl = (no) => {
    request( {url: `https://search.naver.com/search.naver?where=nexearch&sm=top_sug.pre&fbm=1&acr=3&acq=%EB%A1%9C%EB%98%90&qdt=0&ie=utf8&query=%EB%A1%9C%EB%98%90+${no}%ED%9A%8C`},
    function (error, response, body) {
        const $ = cheerio.load(body);
        var arr = new Array();
        arr.push(no);
        for(let i=0; i< 7; i++){
            var className = $('.num_box .num').eq(i).attr('class');
            var num = className.split('ball');
            arr.push(num[1]);
            console.log(num[1]);
        }
        var json = JSON.stringify(arr);
        fs.appendFile("data/rotto", json+'\n', 'utf8', (err)=>{
            console.log('write');
        })
    })
}

for(let i=0; i<10; i++){
    setTimeout(()=>{
        getRottoUrl(927+i);
    }, 1000);
}