var fs = require('fs');
fs.readFile('sample.txt', 'utf-8',function(arr, data){
    console.log(data);
});